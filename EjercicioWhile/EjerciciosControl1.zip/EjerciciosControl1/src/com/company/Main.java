package com.company;

public class Main {

    public static void main(String[] args) {

        int numerozero;
        numerozero = -15;

        if (numerozero < 0) {
            System.out.println("Es negativo");
        } else if (numerozero > 0){
            System.out.println("Es positivo");
        } else {
            System.out.println("Es 0");
        }
    }
}
